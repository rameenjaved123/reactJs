import React from 'react';
import ReactDOM from "react-dom";
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
// import combineReducers from './reducers/rootReducer'
import thunk from 'redux-thunk';
import MainPage from './components/MainPage'
import allReducers from './reducers';

//store is basically redux store (storing all the data in it)
const store = createStore(allReducers);

ReactDOM.render(
  //provider makes the store available to containers that renders components
  //The Provider component uses something called React Context which allows you to pass the store object to any components that needs to access it without the need to pass props.
  <Provider store={store}>
    <MainPage />
  </Provider>,
  document.getElementById('root')
);
