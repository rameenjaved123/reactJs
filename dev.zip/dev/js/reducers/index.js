//this is constant state of user details
const users =[ {
  firstName: "rameen",
  lastName: "javed",
  Address: "jh",
  Company: "Wancloud",
  Telephone: "03412263383",
  dob: "24sep1996"
},
{
  firstName: "komal",
  lastName: "javed",
  Address: "mangla",
  Company: "roots",
  Telephone: "0341-2232323",
  dob: "27May1993"
}
]
//this is the data being sent to redux store
const allReducers = (state =users, action) => {
  switch (action.type) {
    case 'ADD_USER':
        console.log(action.payload.data);

      return (
        { ...state,
          firstName:action.payload.data.firstName,
          lastName:action.payload.data.lastName,
          Address: action.payload.data.Address,
          Company: action.payload.data.Company,
          Telephone:action.payload.data.Telephone,
          dob: action.payload.data.dob
        });
      
    default:
      return state;
  }
}
export default allReducers;