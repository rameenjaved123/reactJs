//this is constant state of user details
const inititalState =
{users:[ {
  firstName: "rameen",
  lastName: "javed",
  Address: "Mangla Cantt",
  Company: "Wancloud",
  Telephone: "03412263383",
  dob: "24sep1996"
},
{
  firstName: "komal",
  lastName: "javed",
  Address: "mangla",
  Company: "roots",
  Telephone: "0341-2232323",
  dob: "27May1993"
}
]}

//this is the data being sent to redux store
const allReducers = (state =inititalState, action) => {
  switch (action.type) {
    case 'ADD_USER':
    //  console.log(action.payload.data);
      return (
        { 
          ...state,
         users:[...state.users,action.payload.users],
        });
      
    default:
      return state;
  }
}
export default allReducers;