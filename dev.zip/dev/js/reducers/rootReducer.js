import { combineReducers } from "redux";
import allReducers from "./index";

//combining all the reducers in a store
export default combineReducers({
  users:allReducers
});