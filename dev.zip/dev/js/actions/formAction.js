//this is action that consists of type and payload
export const userFunction = (data) => {
  // console.log(data);
  return ({
    type: 'ADD_USER',
    payload: { data }
  });
}
