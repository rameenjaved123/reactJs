//this is action that consists of type and payload
export const userFunction = (users) => {
  // console.log(data);
  return ({
    type: 'ADD_USER',
    payload: { users }
  });
}
