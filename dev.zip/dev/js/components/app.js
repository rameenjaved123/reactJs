import React from 'react';
require('../../scss/style.scss');
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
// import displayData from './displayData';
import * as userFunction from '../actions/formAction';


class App extends React.Component {

    //handle the submission after form submit button gets pressed
    handleSubmit = (e) => {
        e.preventDefault();
        const firstName = this.getFirstName.value;
        const lastName = this.getLastName.value;
        const Address = this.getAddr.value;
        const Company = this.getCompany.value;
        const Telephone = this.getNumber.value;
        const dob = this.getDob.value;

        //storing data fetched form input fields
        const data = {
            id: new Date(),
            firstName,
            lastName,
            Address,
            Company,
            Telephone,
            dob
        }
        //show alert confirmation 
        alert("Data Submitted in redux successfully.")

        //passing data as a paremeter in a function of actions 
        this.props.userFunction(data);
        this.getFirstName.value = '';
        this.getLastName.value = '';
        this.getAddr.value = '';
        this.getCompany.value = '';
        this.getNumber.value = '';
        this.getDob.value = '';
    }


    render() {
        return (
            //form html
            <div>
                <form onSubmit={this.handleSubmit.bind(this)} className="container">
                    <label>
                        First Name:
                    </label>
                    <input required placeholder="First Name" ref={(input) => this.getFirstName = input} type="text">
                    </input>
                    <br /><br />
                    <label>
                        Last Name:
                    </label>
                    <input required placeholder="Last Name" ref={(input) => this.getLastName = input} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Address:
                    </label>
                    <input required placeholder="Complete Address" ref={(input) => this.getAddr = input} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Company:
                    </label >
                    <input required placeholder="Company" ref={(input) => this.getCompany = input} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Number:
                    </label>
                    <input required placeholder="Number Format:0341-3362294 " ref={(input) => this.getNumber = input} type="tel" pattern="[0-9]{4}-[0-9]{7}">
                    </input>
                    <br />
                    <br />
                    <label>
                        DOB:
                    </label>
                    <input required ref={(input) => this.getDob = input} type="date">
                    </input>
                    <br /><br />
                    <button id="btn1">Submit</button>
                </form>


            </div>
        );
    }
}

//mapping state data to properties of component
const mapStateToProps = (state) => {
    return {
        users: state.users
    }
}

//dispatching the output on properties of components
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(userFunction, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(App);
