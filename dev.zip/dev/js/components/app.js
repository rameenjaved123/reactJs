import React from 'react';
require('../../scss/style.scss');
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { BrowserRouter as Router, Switch, Route, NavLink } from 'react-router-dom'
import * as userFunction from '../actions/formAction';
import displayData from './displayData';


class App extends React.Component {

    state = {
        firstName: null,
        lastName: null,
        Address: null,
        Company: null,
        Telephone: null,
        dob: null
    }
    handleChange = (e) => {
        this.setState({
            [e.target.id]: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault();
        // console.log(this.state);
        alert("Data submitted in redux store.")
        this.props.userFunction(this.state);
        e.target.reset();
    }


    render() {
        return (
            //form html
            <div>
                <div>
                    <NavLink id="route2" to="/displayData">Display Data</NavLink>
                </div>
                <form onSubmit={this.handleSubmit} className="container">
                    <label>
                        First Name:
                    </label>
                    <input required placeholder="First Name" onChange={this.handleChange} id="firstName" type="text">
                    </input>
                    <br /><br />
                    <label>
                        Last Name:
                    </label>
                    <input required placeholder="Last Name" id="lastName" onChange={this.handleChange} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Address:
                    </label>
                    <input required placeholder="Complete Address" id="Address" onChange={this.handleChange} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Company:
                    </label >
                    <input required placeholder="Company" id="Company" onChange={this.handleChange} type="text">
                    </input>
                    <br />
                    <br />
                    <label>
                        Number:
                    </label>
                    <input required placeholder="Number Format:0341-3362294 " id="Telephone" onChange={this.handleChange} type="tel" pattern="[0-9]{4}-[0-9]{7}">
                    </input>
                    <br />
                    <br />
                    <label>
                        DOB:
                    </label>
                    <input required type="date" id="dob" onChange={this.handleChange}></input>
                    <br /><br />
                    <button id="btn1">Submit</button>
                </form>


            </div>
        );
    }
}

//mapping state data to properties of component
const mapStateToProps = (state) => {
    return {
        users: state.users
    }
}

//dispatching the output on properties of components
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(userFunction, dispatch);
}
export default connect(mapStateToProps, mapDispatchToProps)(App);
