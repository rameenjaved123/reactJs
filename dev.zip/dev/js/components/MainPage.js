import React from 'react';
require('../../scss/style.scss');
import { BrowserRouter as Router,Switch } from 'react-router-dom'
// import { browserHistory} from 'react-router-dom'
import {
    Route,
    NavLink,
    HashRouter
} from "react-router-dom";
import App from './app';
import displayData from './displayData';

//funciton using fat arrow(ES6)
class MainPage extends React.Component {

    render() {
        return (
            <HashRouter>
                <div>

                    <ul>
                        <li>
                            <NavLink to="/app" id="route1">Form Page</NavLink>
                            <div className="content">
                                <Route path="/app" component={App} />
                            </div>
                        </li>
                        <li>
                            <NavLink id="route2" to="/displayData">Display Data</NavLink>
                            <div>
                                <Route path="/displayData" component={displayData} />
                            </div>

                        </li>
                    </ul>

                </div>

            </HashRouter>
        );
    }
}
export default MainPage;