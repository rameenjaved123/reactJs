import React from 'react';
require('../../scss/style.scss');
import * as userFunction from '../actions/formAction';
import { connect } from 'react-redux';
import { bindActionCreators, compose } from 'redux';
class displayData extends React.Component {
    render() {
        const data = this.props.users;
        // console.log(data);
        const list = data.map(user => {
            return (
                <div className="divDisplay" key={user.firstName}>
                    <p>{user.firstName}</p>
                    <p>{user.Address}</p>
                    <p>{user.Company}</p>
                    <p>{user.Telephone}</p>
                    <p>{user.dob}</p>
                </div>
            )
        })
        return (
            <div>
                <ul>
                    {list}
                </ul>
            </div>
        );
    }
}

// mapping state data to properties of component
const mapStateToProps = (state) => {
    return {
        users: state.users
    }
}

// //dispatching the output on properties of components
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(userFunction, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(displayData);