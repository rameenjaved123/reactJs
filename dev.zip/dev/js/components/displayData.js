import React from 'react';
require('../../scss/style.scss');
import * as userFunction from '../actions/formAction';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
class displayData extends React.Component {

    render() {
        return (
            <div>
                <ul>
                    {this.props.users.map((user) => {
                        return (
                            <li key={user.firstName}>
                                <p>
                                    Name:{user.firstName}{user.lastName}
                                    <br />
                                    Company:{user.Company}
                                    <br />
                                    Address:{user.Address}
                                    <br />
                                    Telephone:{user.Telephone}
                                    <br />
                                    Date of birth:{user.dob}</p>
                            </li>
                        );
                    })}
                </ul>
            </div>
        );
    }
}

//mapping state data to properties of component
const mapStateToProps = (state) => {
    return {
        users: state.users
    }
}

//dispatching the output on properties of components
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(userFunction, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(displayData);