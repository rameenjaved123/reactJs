import React from 'react';
require('../../scss/style.scss');
import * as userFunction from '../actions/formAction';
import { connect } from 'react-redux';
import { bindActionCreators, compose } from 'redux';
class displayData extends React.Component {
    render() {
        const data = this.props.users;
        // console.log(data);
        const list = data.map(user => {
            return (
                <div className="divDisplay" key={user.firstName}>
                    <p><strong>First name</strong><br/><br/>{user.firstName}</p>
                    <p><strong>Last name</strong><br/><br/>{user.lastName}</p>
                    <p><strong>Address</strong><br/><br/>{user.Address}</p>
                    <p><strong>Company</strong><br/><br/>{user.Company}</p>
                    <p><strong>Telephone Number</strong><br/><br/>{user.Telephone}</p>
                    <p><strong>Date of birth</strong><br/><br/>{user.dob}</p>
                </div>
            )
        })
        return (
            <div>
                <ul>
                    {list}
                </ul>
            </div>
        );
    }
}

// mapping state data to properties of component
const mapStateToProps = (state) => {
    return {
        users: state.users
    }
}

// //dispatching the output on properties of components
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(userFunction, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(displayData);